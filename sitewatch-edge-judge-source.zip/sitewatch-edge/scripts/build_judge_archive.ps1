$ErrorActionPreference = 'Stop'

$projectRoot = (Resolve-Path -LiteralPath (Split-Path -Parent $PSScriptRoot)).Path
$dist = Join-Path $projectRoot 'dist'
$stage = Join-Path $dist 'sitewatch-edge'
$archive = Join-Path $dist 'sitewatch-edge-judge-source.zip'

New-Item -ItemType Directory -Force -Path $dist | Out-Null
if (Test-Path -LiteralPath $stage) {
  $resolvedStage = (Resolve-Path -LiteralPath $stage).Path
  if (-not $resolvedStage.StartsWith($dist, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to remove unexpected staging path: $resolvedStage"
  }
  Remove-Item -LiteralPath $resolvedStage -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $stage | Out-Null

$files = @('LICENSE', 'README.md', 'pyproject.toml', 'requirements-lock.txt', '.gitignore')
foreach ($file in $files) {
  Copy-Item -LiteralPath (Join-Path $projectRoot $file) -Destination $stage
}

$directories = @('src', 'tests', 'infra', 'scripts', 'docs', 'evaluation', 'evidence')
foreach ($directory in $directories) {
  Copy-Item -LiteralPath (Join-Path $projectRoot $directory) -Destination $stage -Recurse
}

New-Item -ItemType Directory -Force -Path (Join-Path $stage 'models') | Out-Null
Get-ChildItem -LiteralPath (Join-Path $projectRoot 'models') -File | Where-Object {
  $_.Extension -notin @('.onnx', '.pt')
} | Copy-Item -Destination (Join-Path $stage 'models')

New-Item -ItemType Directory -Force -Path (Join-Path $stage 'demo') | Out-Null
Copy-Item -LiteralPath (Join-Path $projectRoot 'demo\slides') -Destination (Join-Path $stage 'demo') -Recurse
Copy-Item -LiteralPath (Join-Path $projectRoot 'demo\NARRATION.md') -Destination (Join-Path $stage 'demo')
Copy-Item -LiteralPath (Join-Path $projectRoot 'demo\sitewatch-edge-demo.srt') -Destination (Join-Path $stage 'demo')

Get-ChildItem -LiteralPath $stage -Recurse -Directory -Filter '__pycache__' | Remove-Item -Recurse -Force
Get-ChildItem -LiteralPath $stage -Recurse -Directory -Filter '*.egg-info' | Remove-Item -Recurse -Force
if (Test-Path -LiteralPath $archive) { Remove-Item -LiteralPath $archive -Force }
Compress-Archive -LiteralPath $stage -DestinationPath $archive -CompressionLevel Optimal
$hash = Get-FileHash -Algorithm SHA256 -LiteralPath $archive
$hash.Hash.ToLowerInvariant() | Set-Content -LiteralPath "$archive.sha256" -Encoding ascii
$hash
