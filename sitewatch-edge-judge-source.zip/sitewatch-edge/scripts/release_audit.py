from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).parents[1]


def hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_check(label: str, command: list[str]) -> tuple[str, bool, str]:
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
    detail = (result.stdout + result.stderr).strip().splitlines()
    return label, result.returncode == 0, detail[-1] if detail else "no output"


def main() -> int:
    checks: list[tuple[str, bool, str]] = []
    python = str(ROOT / ".venv" / "Scripts" / "python.exe")
    checks.append(run_check("unit tests", [python, "-m", "pytest", "-q"]))
    checks.append(run_check("lint", [python, "-m", "ruff", "check", "src", "tests", "infra", "scripts"]))
    manifest = json.loads((ROOT / "models" / "MODEL_MANIFEST.json").read_text(encoding="utf-8"))
    for model in manifest["models"]:
        if str(model.get("status", "")).startswith("not used"):
            continue
        path = ROOT / "models" / model["file"]
        actual = hash_file(path) if path.exists() else "missing"
        checks.append((f"model {model['file']}", actual == model["sha256"], actual))
    required = {
        "architecture": ROOT / "docs" / "architecture.svg",
        "technical report": ROOT / "docs" / "TECHNICAL_REPORT.md",
        "evaluation report": ROOT / "docs" / "EVALUATION_REPORT.md",
        "submission draft": ROOT / "docs" / "DEVPOST_SUBMISSION_DRAFT.md",
        "raw evaluation evidence": ROOT / "evidence" / "evaluation-image-level.json",
        "video-path evidence": ROOT / "evidence" / "video-path-verification.mp4",
        "judge source archive": ROOT / "dist" / "sitewatch-edge-judge-source.zip",
        "AWS live round-trip": ROOT / "evidence" / "aws-live-roundtrip.json",
        "final demo video": ROOT / "evidence" / "sitewatch-edge-demo.mp4",
        "submission confirmation": ROOT / "evidence" / "submission-confirmation.md",
    }
    for label, path in required.items():
        checks.append((label, path.exists() and path.stat().st_size > 0, str(path.relative_to(ROOT))))
    width = max(len(label) for label, _, _ in checks)
    for label, passed, detail in checks:
        print(f"{'PASS' if passed else 'MISS'}  {label:<{width}}  {detail}")
    missing = [label for label, passed, _ in checks if not passed]
    if missing:
        print(f"\nRelease incomplete: {', '.join(missing)}")
        return 1
    print("\nRelease audit passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
