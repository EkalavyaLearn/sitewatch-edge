# Final IP, eligibility, and institutional review

Prepared: 10 October 2026

This is a decision gate, not evidence that the unchecked statements are true.
The entry must not be submitted until the participant confirms every item below.

## Verified from repository evidence

- The repository declares AGPL-3.0-only because the PPE model weights are
  AGPL-3.0; the OpenCV YOLOX model is Apache-2.0.
- Model source URLs, upstream licences, and SHA-256 hashes are recorded in
  `models/MODEL_MANIFEST.json`.
- The seven-image functional evaluation sources and intended uses are recorded in
  `docs/DATA_MANIFEST.md` and `evaluation/manifest.csv`.
- The judge archive excludes the original evaluation photographs and model
  binaries. It includes source code, reports, manifests, slides, and test evidence.
- The published demonstration is unlisted and uses transformed, annotated frames:
  https://youtu.be/_lm_0y-pqVk.

## Participant confirmations required

- [ ] Dr. N. Chaitanya Kumar is the entrant/team representative and is the only
  team member, or all additional team members have been listed.
- [ ] Every entrant is of legal age, resides in an eligible territory, is not an
  organizer/employee/household member excluded by the competition rules, and is
  authorized to accept those rules.
- [ ] The entrant owns or is authorized to submit the original SiteWatch Edge
  source code, documentation, narration, and other original materials, with no
  employer or university ownership conflict.
- [ ] The exact public affiliation line is approved, or replaced before submission:
  `Professor & Coordinator · KLH University, Bowrampet`.
- [ ] The entrant approves granting Devpost access to the authorized Google
  identity (`nalamalan@gmail.com`) so the entry can be created and submitted.
- [ ] AWS identity verification is complete, enabling a live deployment without
  exceeding the separately authorized USD 5 monthly budget.

## Submission rule

Do not mark the ownership/IP review complete, claim institutional sponsorship or
approval, or submit the Devpost entry until the participant confirmations above
are documented and the AWS live round-trip evidence passes the release audit.
