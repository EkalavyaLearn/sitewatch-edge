from sitewatch_edge.rules import Box, missing_required_ppe, violates_restricted_zone


def test_restricted_zone_uses_person_centre() -> None:
    zone = [(0, 0), (100, 0), (100, 100), (0, 100)]
    assert violates_restricted_zone(Box(10, 10, 30, 50), zone)
    assert not violates_restricted_zone(Box(110, 10, 130, 50), zone)


def test_missing_required_ppe() -> None:
    assert missing_required_ppe({"person", "helmet"}, {"helmet", "vest"}) == {"vest"}

