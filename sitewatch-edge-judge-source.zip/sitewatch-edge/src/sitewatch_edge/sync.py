from __future__ import annotations

from collections.abc import Callable
from typing import Any

import requests

from .events import OfflineEventQueue


def sync_pending(
    queue: OfflineEventQueue,
    endpoint: str,
    api_key: str,
    *,
    timeout_seconds: float = 5.0,
    post: Callable[..., Any] = requests.post,
) -> tuple[int, int]:
    """Synchronize events; retain failures for the next connectivity window."""
    pending = queue.pending()
    failures: list[dict[str, Any]] = []
    sent = 0
    for incident in pending:
        try:
            response = post(
                endpoint,
                json=incident,
                headers={"x-api-key": api_key},
                timeout=timeout_seconds,
            )
            if 200 <= response.status_code < 300:
                sent += 1
            else:
                failures.append(incident)
        except requests.RequestException:
            failures.append(incident)
    queue.replace(failures)
    return sent, len(failures)

