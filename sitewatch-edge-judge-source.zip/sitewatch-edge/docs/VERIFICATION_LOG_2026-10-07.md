# Verification log — 7 October 2026

## Environment

- Python 3.12
- OpenCV 5.0.0
- Windows CPU target

## Automated checks

- Unit tests: 8 passed
- Ruff: passed
- Python compile check: passed

## OpenCV Zoo YOLOX FP32

- Model SHA-256: `c5c2d13e59ae883e6af3b45daea64af4833a4951c92d116ec270d9ddbe998063`
- Input: OpenCV `basketball1.png`
- Result: two people detected; two restricted-zone alerts shown
- Annotated output: `artifacts/opencv-basketball1-result.jpg`

## OpenCV Zoo YOLOX INT8 negative result

- Model SHA-256: `01a3b0f400b30bc1e45230e991b2e499ab42622485a330021947333fbaf03935`
- Result: OpenCV 5.0.0 DNN graph engine produced output tensors but zero class scores
- Decision: excluded from the application; retained in manifest as a failure case

## PPE model

- Model: Construction Site Safety Hazards v0.3
- Model SHA-256: `55f4dd2f53158eac4ff093d938b9fbda80c99454a03672145bbc36f539988249`
- Input: Pexels 8159 CC0 image
- Result: person 0.91, hardhat 0.82, safety vest 0.85
- Local action: restricted-zone event queued offline
- Annotated output: `artifacts/pexels-8159-result.jpg`

These are functional checks, not an accuracy benchmark. Accuracy claims require a
separate labelled evaluation set and confusion-matrix evidence.

## Small licensed evaluation

- Images: seven
- Person presence: precision 1.00, recall 1.00
- Hardhat presence: precision 1.00, recall 1.00
- Safety-vest presence: precision 1.00, recall 0.60
- Median latency: 79.20 ms; observed p95: 82.33 ms
- Known failures: two safety-vest false negatives

## Video-path check

- Input: ten-frame H.264 sequence derived from the licensed Pexels 8159 image
- Processed: first five frames
- Output: five-frame 640×426 MP4 at 5 fps
- Average inference: 77.97 ms/frame
- Offline incidents queued: one (cooldown suppresses repeated duplicates)

## 8 October regression and release audit

- Unit tests: 12 passed
- Ruff: passed
- Model hashes: passed for the PPE and OpenCV Zoo YOLOX FP32 models
- Local release artifacts: present and non-empty
- Unlisted video: https://youtu.be/_lm_0y-pqVk
- Truthful remaining release-audit misses: live AWS round-trip evidence and final
  Devpost submission confirmation
- AWS signup status: Individual Aadhaar/DigiLocker KYC requires user identity action;
  no AWS resources deployed
