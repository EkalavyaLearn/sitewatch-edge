# AWS receiver local contract verification

Date: 11 October 2026

Scope: local verification only. This is not evidence of an AWS deployment or a
live cloud round trip.

Verified path:

1. A real `Incident` containing a local-only evidence path is appended to the
   offline JSONL queue.
2. The production `sync_pending` client serializes and sends the queued record.
3. A local adapter invokes the production Lambda handler with the same JSON and
   authentication header contract used by API Gateway.
4. The handler accepts the record with HTTP 202 semantics.
5. The queue is cleared after acceptance.
6. The fake DynamoDB table receives the minimised incident metadata, while the
   local evidence path is absent.

Automated evidence: `tests/test_cloud_receiver.py::test_offline_queue_to_receiver_contract`.
CloudFormation validation: `cfn-lint 1.40.4 infra/template.yaml` passes.

Remaining external gate: activate the authorized AWS account, deploy the stack,
perform a sanitized live request/table verification, and create
`evidence/aws-live-roundtrip.json`.
