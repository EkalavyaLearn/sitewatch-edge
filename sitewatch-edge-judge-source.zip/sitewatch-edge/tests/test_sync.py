from dataclasses import dataclass

import requests

from sitewatch_edge.events import Incident, OfflineEventQueue
from sitewatch_edge.sync import sync_pending


@dataclass
class Response:
    status_code: int


def test_successful_sync_clears_queue(tmp_path) -> None:
    queue = OfflineEventQueue(tmp_path / "events.jsonl")
    queue.append(Incident(event_type="missing_ppe", confidence=0.9))

    sent, retained = sync_pending(
        queue,
        "https://example.invalid/incidents",
        "test-key",
        post=lambda *args, **kwargs: Response(202),
    )

    assert (sent, retained) == (1, 0)
    assert queue.pending() == []


def test_network_outage_retains_event_for_later_success(tmp_path) -> None:
    queue = OfflineEventQueue(tmp_path / "events.jsonl")
    queue.append(Incident(event_type="restricted_zone_entry", confidence=0.92))

    def offline(*_args, **_kwargs):
        raise requests.ConnectionError("simulated outage")

    assert sync_pending(queue, "https://example.invalid", "test-key", post=offline) == (0, 1)
    assert len(queue.pending()) == 1
    assert sync_pending(
        queue,
        "https://example.invalid",
        "test-key",
        post=lambda *_args, **_kwargs: Response(202),
    ) == (1, 0)
    assert queue.pending() == []
