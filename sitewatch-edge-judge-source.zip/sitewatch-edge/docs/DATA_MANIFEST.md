# Evaluation asset manifest

## Licence and use review

The functional evaluation uses six individually selected Pexels photographs and
one OpenCV sample image. The Pexels items were downloaded manually for a small,
documented evaluation; no automated extraction or bulk collection was used. The
Pexels Licence permits free use and modification, subject to its prohibited-use
and third-party-rights restrictions. SiteWatch Edge uses the photographs only in
a neutral workplace-safety context, does not imply endorsement by any depicted
person, and publishes only transformed, annotated demonstration frames. Source
pages remain recorded below and in `evaluation/manifest.csv`.

Licence references reviewed 10 October 2026:

- https://www.pexels.com/license/
- https://www.pexels.com/terms-of-service/

## Clean PPE verification image

- Local filename: `artifacts/pexels-8159.jpg`
- Source page: https://www.pexels.com/photo/construction-worker-safety-danger-8159/
- Source image: https://images.pexels.com/photos/8159/pexels-photo.jpg
- Creator: Life Of Pix
- Licence shown by source page: CC0 / free to use
- SHA-256: `405905c4649e0d3bfd5aa2e275e340b41ba26b24b0e38a3a48f5942942e87ab8`
- Use: local inference verification and, with attribution, competition demonstration

## Additional Pexels functional-evaluation images

| Local filename | Source page | Intended label/use |
|---|---|---|
| `artifacts/eval-pexels-10202856.jpg` | https://www.pexels.com/photo/men-working-on-a-construction-site-while-wearing-hard-hats-10202856/ | Multiple workers with hardhats and vests |
| `artifacts/eval-pexels-34670931.jpg` | https://www.pexels.com/photo/construction-worker-holding-hard-hat-outdoors-34670931/ | Worker holding, rather than wearing, a hardhat |
| `artifacts/eval-pexels-35390341.jpg` | https://www.pexels.com/photo/construction-worker-with-hard-hat-and-safety-vest-35390341/ | Worker with hardhat and reflective garment |
| `artifacts/eval-pexels-36697940.jpg` | https://www.pexels.com/photo/warehouse-worker-wearing-headphones-checks-inventory-36697940/ | Worker without hardhat or safety vest |
| `artifacts/eval-pexels-37556464.jpg` | https://www.pexels.com/photo/construction-worker-in-hard-hat-and-safety-vest-37556464/ | Worker with hardhat and high-visibility vest |

These images are excluded from the judge source archive because the archive does
not copy the local `artifacts/` directory. Their source records and aggregate
evaluation results are included.

## OpenCV sample image

- Local filename: `artifacts/opencv-basketball1.png`
- Source: `opencv/opencv` branch `5.x`, `samples/data/basketball1.png`
- Project licence: Apache-2.0
- Use: person-detection and restricted-zone regression check

## PPE model-card example

- Local filename: `artifacts/ppe-model-example.jpg`
- Source: `constructelligence/construction-site-safety-hazards/example.jpg`
- SHA-256: `0d80be78cb9c050ad88140786173305db88e5c2d1b17bcf3024e445de9f98b96`
- Use: internal model regression check only
- Final-video status: excluded until the source-image attribution is confirmed
