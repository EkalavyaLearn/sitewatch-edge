# AWS signup confirmation

Observed: 11 October 2026 (Asia/Kolkata)

AWS displayed **Congratulations! Thank you for signing up for AWS.** after the
professor completed DigiLocker/Aadhaar and SMS verification. The confirmation
page states that AWS is activating the account and will send an email when
activation is complete.

This confirms signup and identity-verification completion only. It is not evidence
that the account is active, that resources have been deployed, or that a live AWS
round trip has occurred.
