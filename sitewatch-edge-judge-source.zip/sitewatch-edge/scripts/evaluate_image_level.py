from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from statistics import median

import cv2

from sitewatch_edge.vision import OpenCVYoloV8Detector

CLASSES = ("person", "hardhat", "safety vest")


def safe_divide(numerator: int, denominator: int) -> float:
    return numerator / denominator if denominator else 0.0


def score_class(rows: list[dict], class_name: str) -> dict[str, float | int]:
    tp = sum(row["truth"][class_name] and row["predicted"][class_name] for row in rows)
    tn = sum(not row["truth"][class_name] and not row["predicted"][class_name] for row in rows)
    fp = sum(not row["truth"][class_name] and row["predicted"][class_name] for row in rows)
    fn = sum(row["truth"][class_name] and not row["predicted"][class_name] for row in rows)
    precision = safe_divide(tp, tp + fp)
    recall = safe_divide(tp, tp + fn)
    return {
        "tp": tp,
        "tn": tn,
        "fp": fp,
        "fn": fn,
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(safe_divide(2 * precision * recall, precision + recall), 4),
        "accuracy": round(safe_divide(tp + tn, tp + tn + fp + fn), 4),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Small licensed image-level PPE evaluation")
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    detector = OpenCVYoloV8Detector(args.model)
    results: list[dict] = []
    with args.manifest.open(newline="", encoding="utf-8") as stream:
        for item in csv.DictReader(stream):
            image = cv2.imread(item["path"])
            if image is None:
                raise FileNotFoundError(item["path"])
            detections = detector.detect(image)
            labels = {detection.label for detection in detections}
            results.append(
                {
                    "id": item["id"],
                    "source_url": item["source_url"],
                    "truth": {name: bool(int(item[name.replace(" ", "_")])) for name in CLASSES},
                    "predicted": {name: name in labels for name in CLASSES},
                    "detections": [
                        {"label": detection.label, "confidence": round(detection.confidence, 4)}
                        for detection in detections
                    ],
                    "inference_ms": round(detector.last_inference_ms, 2),
                    "notes": item["notes"],
                }
            )
    latencies = sorted(row["inference_ms"] for row in results)
    p95_index = max(0, min(len(latencies) - 1, round(0.95 * (len(latencies) - 1))))
    report = {
        "scope": "image-level class-presence functional evaluation; not object-level mAP",
        "images": len(results),
        "opencv_version": cv2.__version__,
        "metrics": {name: score_class(results, name) for name in CLASSES},
        "latency_ms": {
            "median": round(median(latencies), 2),
            "p95": latencies[p95_index],
            "minimum": min(latencies),
            "maximum": max(latencies),
        },
        "results": results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "results"}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

