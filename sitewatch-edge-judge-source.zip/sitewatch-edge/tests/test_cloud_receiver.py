import importlib.util
import json
import os
from pathlib import Path

from sitewatch_edge.events import Incident, OfflineEventQueue
from sitewatch_edge.sync import sync_pending

MODULE_PATH = Path(__file__).parents[1] / "infra" / "receiver" / "app.py"


def load_receiver():
    spec = importlib.util.spec_from_file_location("sitewatch_receiver", MODULE_PATH)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class FakeTable:
    def __init__(self) -> None:
        self.items = []

    def put_item(self, **kwargs) -> None:
        self.items.append(kwargs["Item"])


def test_receiver_rejects_missing_api_key(monkeypatch) -> None:
    monkeypatch.setenv("INGEST_API_KEY", "a" * 32)
    receiver = load_receiver()
    result = receiver.handler({"headers": {}, "body": "{}"}, None)
    assert result["statusCode"] == 401


def test_receiver_accepts_minimised_incident(monkeypatch) -> None:
    secret = "b" * 32
    monkeypatch.setenv("INGEST_API_KEY", secret)
    monkeypatch.setenv("TABLE_NAME", "test")
    receiver = load_receiver()
    table = FakeTable()
    receiver._table = table
    event = {
        "headers": {"X-Api-Key": secret},
        "body": json.dumps(
            {
                "event_id": "event-1",
                "event_type": "restricted_zone_entry",
                "observed_at": "2026-10-07T00:00:00+00:00",
                "confidence": 0.91,
                "source_id": "local-camera",
                "zone_id": "zone-a",
                "evidence_path": "must-not-enter-cloud-record.jpg",
            }
        ),
    }
    result = receiver.handler(event, None)
    assert result["statusCode"] == 202
    assert table.items[0]["event_id"] == "event-1"
    assert "evidence_path" not in table.items[0]
    assert os.environ["TABLE_NAME"] == "test"


class LambdaResponse:
    def __init__(self, status_code: int) -> None:
        self.status_code = status_code


def test_offline_queue_to_receiver_contract(tmp_path, monkeypatch) -> None:
    """Exercise the real client serializer against the real Lambda handler locally."""
    secret = "c" * 32
    monkeypatch.setenv("INGEST_API_KEY", secret)
    monkeypatch.setenv("TABLE_NAME", "test")
    receiver = load_receiver()
    table = FakeTable()
    receiver._table = table

    queue = OfflineEventQueue(tmp_path / "events.jsonl")
    queue.append(
        Incident(
            event_type="missing_ppe",
            confidence=0.87,
            source_id="sitewatch-demo",
            zone_id="loading-bay",
            evidence_path="local-only-frame.jpg",
        )
    )

    def invoke_lambda(_endpoint, *, json, headers, timeout):
        assert timeout == 5.0
        result = receiver.handler({"headers": headers, "body": __import__("json").dumps(json)}, None)
        return LambdaResponse(result["statusCode"])

    assert sync_pending(queue, "local://incident-receiver", secret, post=invoke_lambda) == (1, 0)
    assert queue.pending() == []
    assert len(table.items) == 1
    stored = table.items[0]
    assert stored["event_type"] == "missing_ppe"
    assert stored["source_id"] == "sitewatch-demo"
    assert stored["zone_id"] == "loading-bay"
    assert "evidence_path" not in stored

