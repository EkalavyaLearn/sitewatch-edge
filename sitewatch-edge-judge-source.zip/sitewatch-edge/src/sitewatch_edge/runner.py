from __future__ import annotations

import math
from pathlib import Path
from time import monotonic

import cv2

from .events import Incident, OfflineEventQueue
from .vision import OpenCVYoloV8Detector, OpenCVYoloXDetector, annotate_frame, evaluate_safety

IMAGE_EXTENSIONS = {".bmp", ".jpeg", ".jpg", ".png", ".tif", ".tiff", ".webp"}


def parse_zone(value: str) -> list[tuple[float, float]]:
    try:
        points = [tuple(map(float, point.split(","))) for point in value.split(";")]
    except ValueError as error:
        raise ValueError("zone must use x,y;x,y;x,y format") from error
    if len(points) < 3 or any(len(point) != 2 for point in points):
        raise ValueError("zone must contain at least three x,y points")
    return [(x, y) for x, y in points]


def run_source(
    *,
    model_path: Path,
    detector_type: str,
    source: str,
    output_path: Path,
    queue_path: Path,
    restricted_zone: list[tuple[float, float]] | None,
    required_ppe: set[str] | None,
    max_frames: int | None,
    display: bool,
    cooldown_seconds: float = 5.0,
) -> dict[str, int | float | str]:
    detector = (
        OpenCVYoloV8Detector(model_path)
        if detector_type == "yolov8-ppe"
        else OpenCVYoloXDetector(model_path)
    )
    queue = OfflineEventQueue(queue_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    source_path = Path(source)
    image_mode = source_path.suffix.lower() in IMAGE_EXTENSIONS and source_path.exists()
    if image_mode:
        image = cv2.imread(str(source_path))
        if image is None:
            raise RuntimeError(f"could not read image: {source}")
        frames = [image]
        capture = None
    else:
        capture_source: int | str = int(source) if source.isdigit() else source
        capture = cv2.VideoCapture(capture_source)
        if not capture.isOpened():
            raise RuntimeError(f"could not open source: {source}")
        frames = None

    writer = None
    processed = 0
    incidents = 0
    last_emitted: dict[str, float] = {}
    final_frame = None
    total_inference_ms = 0.0
    try:
        while True:
            if frames is not None:
                if processed >= len(frames):
                    break
                frame = frames[processed]
            else:
                assert capture is not None
                ok, frame = capture.read()
                if not ok:
                    break
            detections = detector.detect(frame)
            total_inference_ms += detector.last_inference_ms
            findings = evaluate_safety(
                detections,
                restricted_zone=restricted_zone,
                required_ppe=required_ppe,
            )
            now = monotonic()
            for finding in findings:
                centre_x, centre_y = finding.box.centre
                finding_key = f"{finding.event_type}:{round(centre_x / 50)}:{round(centre_y / 50)}"
                if now - last_emitted.get(finding_key, -cooldown_seconds) >= cooldown_seconds:
                    queue.append(
                        Incident(
                            event_type=finding.event_type,
                            confidence=finding.confidence,
                            source_id=source,
                            zone_id="restricted-zone" if "zone" in finding.event_type else None,
                        )
                    )
                    last_emitted[finding_key] = now
                    incidents += 1
            final_frame = annotate_frame(
                frame,
                detections,
                findings,
                restricted_zone=restricted_zone,
                inference_ms=detector.last_inference_ms,
            )
            if not image_mode:
                if writer is None:
                    fps = capture.get(cv2.CAP_PROP_FPS) if capture is not None else 0
                    if not fps or not math.isfinite(fps):
                        fps = 20.0
                    writer = cv2.VideoWriter(
                        str(output_path),
                        cv2.VideoWriter_fourcc(*"mp4v"),
                        fps,
                        (final_frame.shape[1], final_frame.shape[0]),
                    )
                writer.write(final_frame)
            if display:
                cv2.imshow("SiteWatch Edge", final_frame)
                if cv2.waitKey(1) & 0xFF in (27, ord("q")):
                    break
            processed += 1
            if max_frames is not None and processed >= max_frames:
                break
        if image_mode and final_frame is not None:
            cv2.imwrite(str(output_path), final_frame)
    finally:
        if capture is not None:
            capture.release()
        if writer is not None:
            writer.release()
        if display:
            cv2.destroyAllWindows()
    return {
        "frames": processed,
        "incidents": incidents,
        "average_inference_ms": round(total_inference_ms / processed, 2) if processed else 0.0,
        "output": str(output_path),
        "opencv": cv2.__version__,
    }
