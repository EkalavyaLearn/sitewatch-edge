$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$rendered = Join-Path $projectRoot 'demo\rendered'
$audio = Join-Path $projectRoot 'demo\audio'
$segments = Join-Path $projectRoot 'demo\segments'
$evidence = Join-Path $projectRoot 'evidence'

New-Item -ItemType Directory -Force -Path $audio, $segments, $evidence | Out-Null

$narrations = @(
  'Hello. I am Doctor N. Chaitanya Kumar from Hyderabad, India. SiteWatch Edge is an offline-first visual safety screening application built with Open C V five and a delayed, privacy-minimised A W S synchronization path.',
  'Small worksites often have unreliable connectivity. A cloud-only camera system can stop producing useful alerts during an outage, while continuous video upload adds bandwidth and privacy cost. SiteWatch Edge keeps inference and the immediate alert on the local computer. It does not recognize faces or identify workers, and every result is an advisory flag for human review.',
  'Open C V five captures the image or video, runs the O N N X protective equipment model on the C P U, performs non-maximum suppression, associates equipment with workers, and evaluates polygonal safety zones. Events enter an append-only local queue. When connectivity and authorization are available, only minimised metadata is sent through API Gateway to Lambda and an encrypted Dynamo D B table with a thirty-day retention limit.',
  'The local interface accepts a consented or licensed image and never sends it to the cloud. Here, Open C V detects one person, one hardhat, and one safety vest in about one tenth of a second on a Windows C P U. The same pipeline supports video, webcam, and R T S P sources, and produces local overlays for supervisor review.',
  'On a small seven-image licensed functional set, person and hardhat presence each achieved an F one score of one point zero. Safety vest presence reached zero point seven five, with two false negatives. Median inference time was seventy-nine point two milliseconds. We report these failures because this prototype is not a safety-rated compliance system and its limits matter.',
  'SiteWatch Edge demonstrates a practical principle: see locally, act responsibly, and synchronize minimally. It keeps the useful safety function available during network outages while preserving human control. Thank you.'
)

Add-Type -AssemblyName System.Speech
$speaker = New-Object System.Speech.Synthesis.SpeechSynthesizer
$speaker.SelectVoice('Microsoft Ravi')
$speaker.Rate = 0

try {
  for ($index = 0; $index -lt $narrations.Count; $index++) {
    $number = '{0:D2}' -f ($index + 1)
    $wavePath = Join-Path $audio "$number.wav"
    $speaker.SetOutputToWaveFile($wavePath)
    $speaker.Speak($narrations[$index])
  }
}
finally {
  $speaker.SetOutputToDefaultAudioDevice()
  $speaker.Dispose()
}

$concatLines = @()
for ($index = 0; $index -lt $narrations.Count; $index++) {
  $number = '{0:D2}' -f ($index + 1)
  $slide = Get-ChildItem -LiteralPath $rendered -Filter "$number-*.png" | Select-Object -First 1
  if (-not $slide) { throw "Missing rendered slide $number" }
  $wavePath = Join-Path $audio "$number.wav"
  $segmentPath = Join-Path $segments "$number.mp4"
  & ffmpeg -y -loglevel error -loop 1 -framerate 30 -i $slide.FullName -i $wavePath `
    -filter_complex '[1:a]apad=pad_dur=1[a]' -map 0:v -map '[a]' -shortest `
    -c:v libx264 -preset medium -tune stillimage -pix_fmt yuv420p -c:a aac -b:a 160k `
    -movflags +faststart $segmentPath
  if ($LASTEXITCODE -ne 0) { throw "ffmpeg failed for slide $number" }
  $concatLines += "file '$($segmentPath.Replace("'", "''"))'"
}

$concatPath = Join-Path $segments 'concat.txt'
$concatLines | Set-Content -LiteralPath $concatPath -Encoding utf8
$uncaptionedPath = Join-Path $segments 'sitewatch-edge-demo-uncaptioned.mp4'
$finalPath = Join-Path $evidence 'sitewatch-edge-demo.mp4'
& ffmpeg -y -loglevel error -f concat -safe 0 -i $concatPath -c copy -movflags +faststart $uncaptionedPath
if ($LASTEXITCODE -ne 0) { throw 'ffmpeg concatenation failed' }
$subtitlePath = Join-Path $projectRoot 'demo\sitewatch-edge-demo.srt'
& ffmpeg -y -loglevel error -i $uncaptionedPath -i $subtitlePath -map 0 -map 1 `
  -c copy -c:s mov_text -metadata:s:s:0 language=eng -movflags +faststart $finalPath
if ($LASTEXITCODE -ne 0) { throw 'ffmpeg subtitle mux failed' }

& ffprobe -v error -show_entries format=duration,size -of default=nw=1 $finalPath
