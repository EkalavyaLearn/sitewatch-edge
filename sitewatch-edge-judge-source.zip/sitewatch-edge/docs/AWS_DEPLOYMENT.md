# AWS deployment gate

Status: prepared and locally validated; not deployed.

Deployment changes an external account and may incur charges. It must be performed
only after the professor authorizes use of the exact AWS account and region.

## Prerequisites

- Approved AWS account and region
- AWS CLI/SAM authentication controlled by the professor
- Approved budget notification email and monthly limit
- Random ingest secret of at least 32 characters, kept outside the repository

## Validation already completed

- `cfn-lint 1.40.4 infra/template.yaml` passes.
- Receiver unit tests cover missing credentials, accepted minimised events, and
  removal of local evidence paths.
- Client tests cover offline retention and later successful delivery.

## Authorized deployment procedure

1. Confirm the account identity and chosen region with `aws sts get-caller-identity`
   only after authorization.
2. The template embeds the tested receiver code, so it can be deployed directly
   through CloudFormation or with SAM without an artifact-packaging bucket.
3. Run `sam deploy --guided --template-file infra/template.yaml`; provide a unique stack name, the ingest secret, the
   approved budget email, and a monthly limit between 1 and 25 US dollars at the
   protected prompts. Never commit `samconfig.toml` or the secret. The template
   creates forecasted-80% and actual-100% budget notifications.
4. Record the API endpoint, DynamoDB table, and budget outputs.
5. Confirm the budget subscription email if AWS requests confirmation.
6. Send one synthetic incident, confirm HTTP 202, query the table, and test a wrong
   key returns HTTP 401.
7. Capture a sanitized live round-trip record at
   `evidence/aws-live-roundtrip.json` without credentials or account identifiers.
8. Delete the stack after judging if continued hosting is not approved.

## Cost boundary

The design uses on-demand/serverless services and a tiny demonstration load, but no
zero-cost guarantee is made. Deployment must stop if a budget control cannot be
configured.
