# AWS account activation pending

Observed: 11 October 2026 (Asia/Kolkata)

The AWS Management Console is accessible in the authorized `ap-south-1` (Mumbai)
region. However, AWS CloudShell could not create its environment and displayed:

> Unable to create the environment. Your account verification is in progress.
> This may take up to two days for new accounts.

No cloud resources were created and no chargeable deployment was attempted. The
SiteWatch Edge stack must remain pending until AWS completes account verification.
