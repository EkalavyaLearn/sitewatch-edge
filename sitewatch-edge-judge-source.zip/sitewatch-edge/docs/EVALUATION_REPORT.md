# Evaluation report

Date: 7 October 2026  
Runtime: OpenCV 5.0.0, Windows CPU  
Model: Construction Site Safety Hazards v0.3 ONNX

## Scope

This is a seven-image, image-level class-presence functional evaluation using six
Pexels images and one Apache-2.0 OpenCV sample. It checks whether each image contains
at least one detected person, worn hardhat, and worn safety vest. It is not
object-level mAP, is too small for generalization claims, and contains no production
site footage.

## Results

| Class | TP | TN | FP | FN | Precision | Recall | F1 |
|---|---:|---:|---:|---:|---:|---:|---:|
| Person | 7 | 0 | 0 | 0 | 1.00 | 1.00 | 1.00 |
| Hardhat | 4 | 3 | 0 | 0 | 1.00 | 1.00 | 1.00 |
| Safety vest | 3 | 2 | 0 | 2 | 1.00 | 0.60 | 0.75 |

Median inference latency was **79.20 ms** per image; observed p95 and maximum were
**82.33 ms** on this small run.

## Failure cases

The model missed safety vests in two licensed images:

- Pexels 34670931: the worker wears an orange reflective vest but holds the hardhat
  instead of wearing it. The model correctly emitted `no-hardhat` but missed the vest.
- Pexels 35390341: the worker wears a hardhat and a narrow reflective safety garment;
  the model emitted `no-safety vest`.

These failures support the UI's advisory wording and human-review requirement.
They also show why absence inference must not be treated as a compliance decision.

## Offline and video behavior

- A five-frame H.264/MP4 sequence was read through `cv2.VideoCapture`, analysed,
  annotated, and written to a five-frame output MP4.
- Average measured OpenCV DNN inference time was 77.97 ms per frame on that run.
- A simulated network outage retained an event in the JSONL queue; a later successful
  response removed it, verified by an automated test.

## Reproduction

```powershell
.\.venv\Scripts\python.exe scripts\evaluate_image_level.py `
  --manifest evaluation\manifest.csv `
  --model models\buildvision-hazards-v0.3.onnx `
  --output artifacts\evaluation-image-level.json
```

Raw report SHA-256:
`7d80c4c2e43590213157ec844e828fe83f39fa82a78103128e3565633ffb1595`.

