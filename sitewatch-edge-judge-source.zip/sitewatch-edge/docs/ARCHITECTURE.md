# Architecture

```text
Camera/video
    |
    v
OpenCV 5 capture + DNN inference (local)
    |
    +--> PPE and zone rule engine --> local warning
    |
    +--> minimised JSON incident --> encrypted local queue
                                      |
                              explicit sync/connectivity
                                      |
                                      v
                       API Gateway --> Lambda --> DynamoDB TTL
```

## Privacy and safety boundaries

- No facial recognition or identity inference.
- No biometric templates.
- Images remain local by default.
- Cloud records contain event metadata, not a person's identity.
- An operator reviews evidence before external escalation.
- Cloud events expire after 30 days in the MVP.

## Meaningful AWS role

The local system remains useful offline. AWS provides durable multi-site event
collection, delayed synchronization, retention enforcement, and a basis for an
authorized dashboard. The final evaluation will demonstrate recovery after a
network outage and verify that queued events arrive exactly once.

The public API endpoint rejects requests without the deployment-specific 32+
character ingest secret. Lambda validates payload size and confidence, strips
unapproved fields such as local evidence paths, and stores only minimised records
in an encrypted on-demand DynamoDB table with a 30-day TTL. The secret is supplied
as a CloudFormation `NoEcho` parameter and must not be committed.
