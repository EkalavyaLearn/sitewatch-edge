from __future__ import annotations

import argparse
import hashlib
import json
import urllib.request
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="Fetch and verify SiteWatch Edge models")
    parser.add_argument("--manifest", type=Path, default=Path("models/MODEL_MANIFEST.json"))
    parser.add_argument("--include-experimental", action="store_true")
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    destination = args.manifest.parent
    destination.mkdir(parents=True, exist_ok=True)
    for model in manifest["models"]:
        if str(model.get("status", "")).startswith("not used") and not args.include_experimental:
            print(f"skip experimental {model['file']}")
            continue
        path = destination / model["file"]
        expected = model["sha256"].lower()
        if path.exists() and sha256(path) == expected:
            print(f"verified {path}")
            continue
        temporary = path.with_suffix(path.suffix + ".part")
        print(f"downloading {model['file']}")
        urllib.request.urlretrieve(model["source"], temporary)
        actual = sha256(temporary)
        if actual != expected:
            temporary.unlink(missing_ok=True)
            raise RuntimeError(f"hash mismatch for {model['file']}: {actual}")
        temporary.replace(path)
        print(f"verified {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

