from sitewatch_edge.events import Incident, OfflineEventQueue


def test_queue_round_trip(tmp_path) -> None:
    queue = OfflineEventQueue(tmp_path / "events.jsonl")
    queue.append(Incident(event_type="restricted_zone", confidence=0.91))
    events = queue.pending()
    assert len(events) == 1
    assert events[0]["event_type"] == "restricted_zone"
    assert events[0]["schema_version"] == 1

