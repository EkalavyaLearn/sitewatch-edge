# Devpost submission draft

## Project name

SiteWatch Edge

## Tagline

Offline-first PPE and restricted-zone screening with OpenCV 5 and delayed AWS sync.

## Inspiration

Cloud-only safety analytics are a poor fit for sites with unreliable connectivity.
Continuous video upload also creates privacy and bandwidth costs. We wanted the
useful safety decision to remain local while giving authorized supervisors a
minimal, delayed record when connectivity returns.

## What it does

SiteWatch Edge analyses images, video, webcams, or RTSP feeds locally. OpenCV 5 DNN
detects workers, hardhats, safety vests, selected missing-PPE classes, and heavy
equipment. A local rule engine associates PPE with workers and checks polygonal
restricted zones. The operator sees an immediate advisory overlay. Events are
queued offline and can later synchronize only privacy-minimised metadata to AWS.

## How we built it

Python and OpenCV 5 provide capture, preprocessing, ONNX inference, NMS, geometry,
annotation, and encoding. A local Flask interface provides an upload-and-review
workflow. The AWS SAM stack uses API Gateway, Lambda, and encrypted DynamoDB with
TTL. The client tolerates outages by retaining unsent JSONL events.

## Challenges

The OpenCV Zoo INT8 YOLOX model produced zero class scores in the OpenCV 5 DNN graph
engine on our Windows test environment. We recorded the failure and selected the
verified FP32 model. PPE absence is also harder than PPE presence, so the interface
distinguishes direct missing-PPE classes from lower-confidence absence inference.

## Accomplishments

- Verified OpenCV 5.0.0 offline ONNX inference.
- Detected a worker, hardhat, and safety vest on a licensed clean image.
- Generated local restricted-zone events with no network.
- Built a tested offline queue and authenticated AWS ingestion contract.
- Excluded local evidence paths from cloud records.

## What we learned

Offline-first is not simply a cached cloud application: local decisions, failure
handling, evidence minimisation, and honest confidence language have to be designed
together. A failed quantized model is valuable evidence when it is captured and
drives a reproducible fallback.

## What's next

Field-test live camera sources, deploy the AWS stack, measure delayed
synchronization, improve temporal tracking, and add a supervisor-reviewed zone
editor.

## Built with

OpenCV 5, Python, NumPy, ONNX, Flask, AWS SAM, API Gateway, Lambda, DynamoDB.

## Links still required

- Repository/archive: `dist/sitewatch-edge-judge-source.zip` is complete locally;
  a judge-accessible delivery location is still required.
- Demo video: https://youtu.be/_lm_0y-pqVk (unlisted)
- Live endpoint or screen-share arrangement: pending AWS activation, deployment,
  and live round-trip evidence.
