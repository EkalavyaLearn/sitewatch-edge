from __future__ import annotations

import argparse
import json
from pathlib import Path

from .events import Incident, OfflineEventQueue
from .runner import parse_zone, run_source


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="sitewatch")
    subparsers = parser.add_subparsers(dest="command", required=True)
    simulate = subparsers.add_parser("simulate", help="Generate local test incidents")
    simulate.add_argument("--events", type=int, default=1)
    simulate.add_argument("--queue", type=Path, default=Path("artifacts/pending-events.jsonl"))
    detect = subparsers.add_parser("detect", help="Run offline OpenCV 5 safety analysis")
    detect.add_argument("--model", type=Path, required=True)
    detect.add_argument("--detector", choices=("yolox", "yolov8-ppe"), default="yolox")
    detect.add_argument("--source", required=True, help="Image/video/RTSP path or camera index")
    detect.add_argument("--output", type=Path, required=True)
    detect.add_argument("--queue", type=Path, default=Path("artifacts/pending-events.jsonl"))
    detect.add_argument("--zone", help="Restricted polygon in pixels: x,y;x,y;x,y")
    detect.add_argument("--required-ppe", default="", help="Comma-separated detector labels")
    detect.add_argument("--max-frames", type=int)
    detect.add_argument("--display", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.command == "simulate":
        queue = OfflineEventQueue(args.queue)
        for index in range(args.events):
            queue.append(
                Incident(
                    event_type="simulation_missing_helmet",
                    confidence=0.90 + (index % 5) / 100,
                    source_id="simulation",
                    zone_id="demo-zone",
                )
            )
        print(f"Queued {args.events} incident(s) at {args.queue}")
        return 0
    if args.command == "detect":
        result = run_source(
            model_path=args.model,
            detector_type=args.detector,
            source=args.source,
            output_path=args.output,
            queue_path=args.queue,
            restricted_zone=parse_zone(args.zone) if args.zone else None,
            required_ppe={item.strip().lower() for item in args.required_ppe.split(",") if item.strip()},
            max_frames=args.max_frames,
            display=args.display,
        )
        print(json.dumps(result, indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
