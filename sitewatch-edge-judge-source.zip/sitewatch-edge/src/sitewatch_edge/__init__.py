"""SiteWatch Edge offline safety monitoring package."""

__version__ = "0.1.0"

