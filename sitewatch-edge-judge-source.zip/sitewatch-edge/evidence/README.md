# Evidence bundle

Generated evidence that can be shared with judges:

- `evaluation-image-level.json`: raw seven-image functional evaluation
- `video-path-verification.mp4`: five-frame annotated video-path check
- `video-verification-events.jsonl`: corresponding minimised incident event
- `sitewatch-edge-demo.mp4`: 2:32 narrated competition demonstration, H.264/AAC,
  1920×1080, with an English subtitle track; SHA-256
  `f2ec4826e99112f9874403f0e6882f56a38ab90441c707b96283a5f49993629b`
- `youtube-published-unlisted.png`: YouTube Studio publication confirmation captured
  on 2026-10-07. Judge-accessible unlisted link: https://youtu.be/_lm_0y-pqVk

Required before release:

- `aws-live-roundtrip.json`: sanitized live AWS deployment evidence
- `submission-confirmation.md`: final Devpost confirmation, timestamp, and URL

Judge source archive: `dist/sitewatch-edge-judge-source.zip`. Rebuilt 2026-10-09;
SHA-256 `b3548df6853ce0c80ec1761458f4155a40aa29f7f2787c6712e653d5e0181278`.
The script `scripts/build_judge_archive.ps1` prints the current hash after each build.
