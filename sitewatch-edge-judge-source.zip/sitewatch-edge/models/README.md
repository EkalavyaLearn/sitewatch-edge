# Model files

Place approved ONNX model files here. Record the source URL, version, licence,
hash, classes, training data provenance, and any restrictions in the evaluation
report. Model binaries are intentionally not committed until licensing is checked.

The initial restricted-zone detector is the OpenCV Zoo YOLOX FP32 ONNX model.
Its source, hash, and licence are pinned in `MODEL_MANIFEST.json`; a copy of its
Apache-2.0 licence is stored as `OPENCV_ZOO_YOLOX_LICENSE.txt`. The INT8 variant
is recorded but not used because local OpenCV 5.0.0 verification produced zero
class scores from that graph.
