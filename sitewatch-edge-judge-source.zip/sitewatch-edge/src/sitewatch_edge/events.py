from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from uuid import uuid4


@dataclass(frozen=True)
class Incident:
    event_type: str
    confidence: float
    source_id: str = "local-camera"
    zone_id: str | None = None
    evidence_path: str | None = None
    event_id: str = field(default_factory=lambda: str(uuid4()))
    observed_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    schema_version: int = 1

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class OfflineEventQueue:
    """Append-only JSONL queue that works without network access."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, incident: Incident) -> None:
        with self.path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(incident.to_dict(), sort_keys=True) + "\n")

    def pending(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        with self.path.open("r", encoding="utf-8") as stream:
            return [json.loads(line) for line in stream if line.strip()]

    def replace(self, incidents: list[dict[str, Any]]) -> None:
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        with temporary.open("w", encoding="utf-8") as stream:
            for incident in incidents:
                stream.write(json.dumps(incident, sort_keys=True) + "\n")
        temporary.replace(self.path)
