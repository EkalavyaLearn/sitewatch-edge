from io import BytesIO

import cv2
import numpy as np

from sitewatch_edge.rules import Box
from sitewatch_edge.vision import Detection
from sitewatch_edge.webapp import create_app


class FakeDetector:
    last_inference_ms = 12.3

    def detect(self, _frame):
        return [
            Detection("person", 0.9, Box(5, 5, 95, 95)),
            Detection("no-hardhat", 0.8, Box(25, 5, 70, 35)),
        ]


def test_local_ui_analyses_image_and_queues_flag(tmp_path) -> None:
    app = create_app(queue_path=tmp_path / "events.jsonl", detector=FakeDetector())
    app.testing = True
    image = np.zeros((100, 100, 3), dtype=np.uint8)
    ok, encoded = cv2.imencode(".jpg", image)
    assert ok
    response = app.test_client().post(
        "/",
        data={"image": (BytesIO(encoded.tobytes()), "test.jpg")},
        content_type="multipart/form-data",
    )
    assert response.status_code == 200
    assert b"SiteWatch Edge" in response.data
    assert b"missing_hardhat" in response.data
    assert (tmp_path / "events.jsonl").exists()

