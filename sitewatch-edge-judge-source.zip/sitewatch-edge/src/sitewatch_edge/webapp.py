from __future__ import annotations

import argparse
import base64
import os
from pathlib import Path

import cv2
import numpy as np
from flask import Flask, render_template_string, request

from .events import Incident, OfflineEventQueue
from .vision import OpenCVYoloV8Detector, annotate_frame, evaluate_safety

PAGE = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>SiteWatch Edge</title>
  <style>
    :root { color-scheme: dark; font-family: Inter, system-ui, sans-serif; }
    body { margin: 0; background: #07111f; color: #e6eef8; }
    main { width: min(1080px, calc(100% - 32px)); margin: 32px auto; }
    header { display:flex; justify-content:space-between; align-items:end; gap:24px; }
    h1 { margin:0; font-size:clamp(2rem,6vw,4.5rem); letter-spacing:-.05em; }
    .status { color:#7ef0bd; font-weight:700; }
    .card { background:#0d1b2c; border:1px solid #263951; border-radius:18px; padding:20px; margin-top:24px; }
    form { display:grid; grid-template-columns:1fr auto; gap:12px; align-items:center; }
    input[type=file] { width:100%; padding:12px; background:#13243a; border-radius:10px; }
    button { padding:13px 20px; border:0; border-radius:10px; background:#30d99b; color:#04120d; font-weight:800; cursor:pointer; }
    img { display:block; max-width:100%; margin-top:20px; border-radius:14px; }
    .metrics { display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-top:16px; }
    .metric { background:#13243a; padding:14px; border-radius:12px; }
    .metric strong { display:block; font-size:1.6rem; }
    .notice { color:#aebed2; line-height:1.5; }
    .alert { color:#ff8d8d; font-weight:700; }
    @media (max-width:640px) { form,.metrics { grid-template-columns:1fr; } }
  </style>
</head>
<body><main>
  <header><div><div class="status">● OFFLINE ANALYSIS READY</div><h1>SiteWatch Edge</h1></div><div>OpenCV {{ opencv_version }}</div></header>
  <section class="card">
    <p class="notice">Upload a consented or licensed workplace image. Analysis stays on this computer. Results are advisory and require human review.</p>
    <form method="post" enctype="multipart/form-data">
      <input name="image" type="file" accept="image/png,image/jpeg,image/webp" required>
      <button type="submit">Analyse locally</button>
    </form>
    {% if error %}<p class="alert">{{ error }}</p>{% endif %}
    {% if result_image %}
      <div class="metrics">
        <div class="metric"><strong>{{ detection_count }}</strong>detections</div>
        <div class="metric"><strong>{{ finding_count }}</strong>review flags</div>
        <div class="metric"><strong>{{ inference_ms }} ms</strong>local inference</div>
      </div>
      <img src="data:image/jpeg;base64,{{ result_image }}" alt="Annotated safety analysis result">
      {% if findings %}<p class="alert">Review: {{ findings|join(', ') }}</p>{% else %}<p>No configured PPE flags detected.</p>{% endif %}
    {% endif %}
  </section>
</main></body></html>
"""


def create_app(
    model_path: Path | None = None,
    queue_path: Path = Path("artifacts/ui-events.jsonl"),
    *,
    detector=None,
) -> Flask:
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024
    active_detector = detector or OpenCVYoloV8Detector(
        model_path or Path("models/buildvision-hazards-v0.3.onnx")
    )
    queue = OfflineEventQueue(queue_path)

    @app.route("/", methods=["GET", "POST"])
    def index():
        context = {
            "opencv_version": cv2.__version__,
            "error": None,
            "result_image": None,
            "detection_count": 0,
            "finding_count": 0,
            "inference_ms": 0,
            "findings": [],
        }
        if request.method == "POST":
            uploaded = request.files.get("image")
            if uploaded is None or not uploaded.filename:
                context["error"] = "Select an image."
            else:
                raw = uploaded.read()
                frame = cv2.imdecode(np.frombuffer(raw, dtype=np.uint8), cv2.IMREAD_COLOR)
                if frame is None:
                    context["error"] = "The uploaded file is not a readable image."
                else:
                    detections = active_detector.detect(frame)
                    findings = evaluate_safety(
                        detections,
                        required_ppe={"hardhat", "safety vest"},
                    )
                    for finding in findings:
                        queue.append(
                            Incident(
                                event_type=finding.event_type,
                                confidence=finding.confidence,
                                source_id="local-ui-upload",
                            )
                        )
                    annotated = annotate_frame(
                        frame,
                        detections,
                        findings,
                        inference_ms=active_detector.last_inference_ms,
                    )
                    ok, encoded = cv2.imencode(".jpg", annotated, [cv2.IMWRITE_JPEG_QUALITY, 90])
                    if not ok:
                        context["error"] = "Could not encode the result."
                    else:
                        context.update(
                            result_image=base64.b64encode(encoded).decode("ascii"),
                            detection_count=len(detections),
                            finding_count=len(findings),
                            inference_ms=round(active_detector.last_inference_ms, 1),
                            findings=[finding.event_type for finding in findings],
                        )
        return render_template_string(PAGE, **context)

    return app


def main() -> None:
    parser = argparse.ArgumentParser(description="SiteWatch Edge local operator interface")
    parser.add_argument(
        "--model",
        type=Path,
        default=Path("models/buildvision-hazards-v0.3.onnx"),
    )
    parser.add_argument("--port", type=int, default=7860)
    args = parser.parse_args()
    app = create_app(args.model)
    app.run(host=os.environ.get("SITEWATCH_HOST", "127.0.0.1"), port=args.port, debug=False)


if __name__ == "__main__":
    main()

