# SiteWatch Edge — technical report

Status: working draft for the OpenCV AI Competition 2026, powered by AWS  
Internal deadline: 14 October 2026, 23:59 IST

## Problem and users

Small construction, maintenance, warehouse, agriculture, and field-service teams
often have intermittent connectivity and limited safety staffing. Conventional
cloud-only video analytics can stop working at the moment a connection fails and
can create avoidable privacy exposure by uploading continuous footage.

SiteWatch Edge is an offline-first visual screening assistant for site supervisors.
It flags frames that may show missing PPE or a person inside a configured restricted
zone. It is advisory: every flag requires human review and must not be used as an
automated disciplinary or compliance decision.

## Application architecture

OpenCV 5 performs capture, preprocessing, ONNX inference, non-maximum suppression,
zone geometry, overlays, and JPEG/video output locally. Events are appended to a
JSONL queue when no network is available. When an operator enables synchronization,
the client sends only minimised event metadata to an authenticated AWS HTTP API.
Lambda validates and strips the payload before storing it in an encrypted DynamoDB
table with a 30-day TTL.

See `architecture.svg` and `ARCHITECTURE.md`.

## OpenCV 5 implementation

The verified runtime is OpenCV 5.0.0. The application supports:

- OpenCV Zoo YOLOX FP32 ONNX for general person detection;
- Construction Site Safety Hazards v0.3 ONNX for PPE and heavy-equipment classes;
- OpenCV DNN CPU inference without an internet connection;
- image, video, webcam, and RTSP source adapters;
- class-aware NMS, person/PPE association, polygon-zone checks, and overlays;
- a local Flask interface bound to `127.0.0.1` by default.

The OpenCV Zoo INT8 graph was tested and rejected because the local OpenCV 5 DNN
graph engine returned zero class scores. The FP32 model is the verified fallback.

## AWS implementation

The AWS SAM template defines:

- API Gateway HTTP API for delayed incident ingestion;
- Lambda validation and minimisation;
- DynamoDB on-demand storage, encryption at rest, conditional writes, and TTL;
- a deployment-specific 32+ character ingest secret supplied as a `NoEcho`
  CloudFormation parameter.

The receiver has local contract tests. Cloud deployment and live round-trip evidence
remain pending explicit account authorization.

## Current functional evidence

On a CC0 Pexels construction image, the PPE model detected:

- person: 0.91 confidence;
- hardhat: 0.82;
- safety vest: 0.85.

The full-frame restricted-zone rule created a privacy-minimised JSONL event while
offline. The annotated frame shows the local detections and measured OpenCV DNN
latency. On the OpenCV basketball sample, YOLOX detected two people and generated
two visual restricted-zone alerts.

These checks prove functional wiring; they are not a field-accuracy claim.

A separate seven-image licensed functional evaluation achieved person and hardhat
presence F1 of 1.00, but safety-vest presence recall was only 0.60 (F1 0.75) because
of two false negatives. Median CPU inference was 79.20 ms in that run. The small,
curated sample is reported only as functional evidence, not a general accuracy claim.

## Evaluation plan

The final evaluation will report:

1. per-class precision and recall on a labelled, licensed image set;
2. restricted-zone event precision and recall;
3. median, p95, and worst-case CPU inference latency;
4. offline queue durability across process restart;
5. successful delayed synchronization after an induced network outage;
6. duplicate-event handling and unauthorized-request rejection;
7. representative false positives and false negatives.

## Responsible use

- No face recognition, identity inference, biometric templates, or emotion analysis.
- Images stay local by default; the AWS record excludes image paths and identities.
- The UI explicitly labels results as advisory and requires human review.
- Operators must use consented or appropriately licensed footage.
- Confidence thresholds and zones must be validated for each site.
- The model must not make employment, disciplinary, insurance, or legal decisions.
- The system is not safety-rated and cannot replace trained safety personnel.

## Limitations

Missing-PPE classes are materially less accurate than worn-PPE classes. Occlusion,
camera angle, motion blur, low light, nonstandard PPE, and domain shift can cause
misses or false alarms. PPE-to-person association currently uses geometric
containment rather than tracking. The cloud path is not yet deployed, and webcam,
RTSP, and long-duration video operation still require field verification.

## Reproducibility

Dependencies are pinned in `requirements-lock.txt`; model hashes and sources are in
`models/MODEL_MANIFEST.json`; evaluation-asset provenance is in
`docs/DATA_MANIFEST.md`; automated checks run with `python -m pytest` and
`python -m ruff check src tests infra`.
