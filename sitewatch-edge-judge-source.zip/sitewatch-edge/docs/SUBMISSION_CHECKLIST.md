# Competition submission checklist

- [ ] Devpost entry joined under the approved participant/team identity
- [ ] Team representative and all members satisfy eligibility requirements
- [x] Problem statement and target users
- [x] Working OpenCV 5 image/video analysis
- [ ] Meaningful AWS component deployed and demonstrated
- [x] Technical report: problem, users, architecture, implementation, deployment
- [x] Evaluation: metrics, baselines, limitations, and failure cases
- [x] Responsible-use and privacy discussion
- [x] Architecture diagram
- [ ] Judge-accessible repository/archive with pinned dependencies
- [x] Build, deployment, and test instructions
- [ ] Working endpoint or arranged live screen-share demonstration
- [x] Unlisted judge-accessible video, five minutes or less: https://youtu.be/_lm_0y-pqVk
- [ ] Final ownership/IP and institutional-affiliation review
- [ ] Final professor approval of submitted text and links
- [ ] Submission confirmation captured as evidence
