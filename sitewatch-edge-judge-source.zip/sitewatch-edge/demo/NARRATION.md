# Demo narration

## 1 — Title

Hello. I am Dr. N. Chaitanya Kumar from Hyderabad, India. SiteWatch Edge is an
offline-first visual safety screening application built with OpenCV 5 and a delayed,
privacy-minimised AWS synchronization path.

## 2 — Problem

Small worksites often have unreliable connectivity. A cloud-only camera system can
stop producing useful alerts during an outage, while continuous video upload adds
bandwidth and privacy cost. SiteWatch Edge keeps inference and the immediate alert
on the local computer. It does not recognize faces or identify workers, and every
result is an advisory flag for human review.

## 3 — Architecture

OpenCV 5 captures the image or video, runs the ONNX PPE model on the CPU, performs
non-maximum suppression, associates PPE with workers, and evaluates polygonal safety
zones. Events enter an append-only local queue. When connectivity and authorization
are available, only minimised metadata is sent through API Gateway to Lambda and an
encrypted DynamoDB table with a thirty-day retention limit.

## 4 — Demo

The local interface accepts a consented or licensed image and never sends it to the
cloud. Here, OpenCV detects one person, one hardhat, and one safety vest in about one
tenth of a second on a Windows CPU. The same pipeline supports video, webcam, and
RTSP sources, and produces local overlays for supervisor review.

## 5 — Evaluation

On a small seven-image licensed functional set, person and hardhat presence each
achieved an F one score of one point zero. Safety-vest presence reached zero point
seven five, with two false negatives. Median inference time was seventy-nine point
two milliseconds. We report these failures because this prototype is not a
safety-rated compliance system and its limits matter.

## 6 — Close

SiteWatch Edge demonstrates a practical principle: see locally, act responsibly,
and synchronize minimally. It keeps the useful safety function available during
network outages while preserving human control. Thank you.

