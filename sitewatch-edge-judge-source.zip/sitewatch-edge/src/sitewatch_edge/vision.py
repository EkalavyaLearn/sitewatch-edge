from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from time import perf_counter

import cv2
import numpy as np

from .rules import Box, missing_required_ppe, violates_restricted_zone

COCO_CLASSES = (
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck",
    "boat", "traffic light", "fire hydrant", "stop sign", "parking meter", "bench",
    "bird", "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra",
    "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
    "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove",
    "skateboard", "surfboard", "tennis racket", "bottle", "wine glass", "cup", "fork",
    "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange", "broccoli",
    "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch", "potted plant",
    "bed", "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard",
    "cell phone", "microwave", "oven", "toaster", "sink", "refrigerator", "book",
    "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush",
)

PPE_CLASSES = (
    "person",
    "hardhat",
    "no-hardhat",
    "safety vest",
    "no-safety vest",
    "no-mask",
    "gloves",
    "safety shoes",
    "excavator",
    "wheel loader",
    "dump truck",
    "goggles",
    "no-goggles",
    "no-gloves",
)


@dataclass(frozen=True)
class Detection:
    label: str
    confidence: float
    box: Box


@dataclass(frozen=True)
class SafetyFinding:
    event_type: str
    confidence: float
    box: Box
    details: str


def letterbox(image: np.ndarray, size: tuple[int, int]) -> tuple[np.ndarray, float]:
    target_width, target_height = size
    ratio = min(target_width / image.shape[1], target_height / image.shape[0])
    resized_width = max(1, round(image.shape[1] * ratio))
    resized_height = max(1, round(image.shape[0] * ratio))
    canvas = np.full((target_height, target_width, 3), 114, dtype=np.float32)
    resized = cv2.resize(image, (resized_width, resized_height), interpolation=cv2.INTER_LINEAR)
    canvas[:resized_height, :resized_width] = resized.astype(np.float32)
    return canvas, ratio


class OpenCVYoloXDetector:
    """Run the Apache-2.0 OpenCV Zoo YOLOX model using OpenCV 5 DNN."""

    def __init__(
        self,
        model_path: str | Path,
        *,
        labels: tuple[str, ...] = COCO_CLASSES,
        confidence_threshold: float = 0.45,
        nms_threshold: float = 0.50,
        input_size: tuple[int, int] = (640, 640),
    ) -> None:
        if int(cv2.__version__.split(".", maxsplit=1)[0]) < 5:
            raise RuntimeError(f"OpenCV 5 is required; found {cv2.__version__}")
        self.labels = labels
        self.confidence_threshold = confidence_threshold
        self.nms_threshold = nms_threshold
        self.input_size = input_size
        self.net = cv2.dnn.readNetFromONNX(str(model_path))
        self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
        self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
        self.grids, self.strides = self._anchors()
        self.last_inference_ms = 0.0

    def _anchors(self) -> tuple[np.ndarray, np.ndarray]:
        grids: list[np.ndarray] = []
        expanded: list[np.ndarray] = []
        for stride in (8, 16, 32):
            height = self.input_size[1] // stride
            width = self.input_size[0] // stride
            x_values, y_values = np.meshgrid(np.arange(width), np.arange(height))
            grid = np.stack((x_values, y_values), axis=2).reshape(1, -1, 2)
            grids.append(grid)
            expanded.append(np.full((*grid.shape[:2], 1), stride))
        return np.concatenate(grids, axis=1), np.concatenate(expanded, axis=1)

    def detect(self, frame: np.ndarray) -> list[Detection]:
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        prepared, ratio = letterbox(rgb, self.input_size)
        blob = np.transpose(prepared, (2, 0, 1))[np.newaxis, :, :, :]
        self.net.setInput(blob)
        started = perf_counter()
        output = self.net.forward(self.net.getUnconnectedOutLayersNames())[0]
        self.last_inference_ms = (perf_counter() - started) * 1000
        return self._postprocess(output, ratio)

    def _postprocess(self, output: np.ndarray, ratio: float) -> list[Detection]:
        predictions = output[0].copy()
        predictions[:, :2] = (predictions[:, :2] + self.grids[0]) * self.strides[0]
        predictions[:, 2:4] = np.exp(predictions[:, 2:4]) * self.strides[0]
        scores = predictions[:, 4:5] * predictions[:, 5:]
        class_ids = np.argmax(scores, axis=1)
        confidences = np.max(scores, axis=1)
        boxes = np.ones_like(predictions[:, :4])
        boxes[:, 0] = predictions[:, 0] - predictions[:, 2] / 2
        boxes[:, 1] = predictions[:, 1] - predictions[:, 3] / 2
        boxes[:, 2] = predictions[:, 2]
        boxes[:, 3] = predictions[:, 3]
        keep = cv2.dnn.NMSBoxesBatched(
            boxes.tolist(),
            confidences.tolist(),
            class_ids.tolist(),
            self.confidence_threshold,
            self.nms_threshold,
        )
        results: list[Detection] = []
        for index in np.asarray(keep).reshape(-1):
            class_id = int(class_ids[index])
            x, y, width, height = boxes[index] / ratio
            results.append(
                Detection(
                    label=self.labels[class_id] if class_id < len(self.labels) else str(class_id),
                    confidence=float(confidences[index]),
                    box=Box(float(x), float(y), float(x + width), float(y + height)),
                )
            )
        return results


class OpenCVYoloV8Detector:
    """Run an Ultralytics-style YOLOv8 ONNX export through OpenCV 5 DNN."""

    def __init__(
        self,
        model_path: str | Path,
        *,
        labels: tuple[str, ...] = PPE_CLASSES,
        confidence_threshold: float = 0.35,
        nms_threshold: float = 0.50,
        input_size: tuple[int, int] = (640, 640),
    ) -> None:
        if int(cv2.__version__.split(".", maxsplit=1)[0]) < 5:
            raise RuntimeError(f"OpenCV 5 is required; found {cv2.__version__}")
        self.labels = labels
        self.confidence_threshold = confidence_threshold
        self.nms_threshold = nms_threshold
        self.input_size = input_size
        self.net = cv2.dnn.readNetFromONNX(str(model_path))
        self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
        self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
        self.last_inference_ms = 0.0

    def detect(self, frame: np.ndarray) -> list[Detection]:
        prepared, ratio, pad_x, pad_y = _letterbox_centered(frame, self.input_size)
        blob = cv2.dnn.blobFromImage(
            prepared,
            scalefactor=1 / 255.0,
            size=self.input_size,
            swapRB=True,
            crop=False,
        )
        self.net.setInput(blob)
        started = perf_counter()
        raw = self.net.forward(self.net.getUnconnectedOutLayersNames())[0]
        self.last_inference_ms = (perf_counter() - started) * 1000
        predictions = raw[0].T
        scores = predictions[:, 4:]
        class_ids = np.argmax(scores, axis=1)
        confidences = np.max(scores, axis=1)
        boxes_xywh = np.empty_like(predictions[:, :4])
        boxes_xywh[:, 0] = predictions[:, 0] - predictions[:, 2] / 2
        boxes_xywh[:, 1] = predictions[:, 1] - predictions[:, 3] / 2
        boxes_xywh[:, 2:] = predictions[:, 2:4]
        candidate_indices = np.flatnonzero(confidences >= self.confidence_threshold)
        if candidate_indices.size == 0:
            return []
        candidate_boxes = boxes_xywh[candidate_indices]
        candidate_scores = confidences[candidate_indices]
        candidate_classes = class_ids[candidate_indices]
        keep = cv2.dnn.NMSBoxesBatched(
            candidate_boxes.tolist(),
            candidate_scores.tolist(),
            candidate_classes.tolist(),
            self.confidence_threshold,
            self.nms_threshold,
        )
        results: list[Detection] = []
        for kept_index in np.asarray(keep).reshape(-1):
            source_index = candidate_indices[int(kept_index)]
            class_id = int(class_ids[source_index])
            x, y, width, height = boxes_xywh[source_index]
            x = (x - pad_x) / ratio
            y = (y - pad_y) / ratio
            width /= ratio
            height /= ratio
            results.append(
                Detection(
                    label=self.labels[class_id] if class_id < len(self.labels) else str(class_id),
                    confidence=float(confidences[source_index]),
                    box=Box(float(x), float(y), float(x + width), float(y + height)),
                )
            )
        return results


def _letterbox_centered(
    image: np.ndarray, size: tuple[int, int]
) -> tuple[np.ndarray, float, int, int]:
    target_width, target_height = size
    ratio = min(target_width / image.shape[1], target_height / image.shape[0])
    resized_width = max(1, round(image.shape[1] * ratio))
    resized_height = max(1, round(image.shape[0] * ratio))
    pad_x = (target_width - resized_width) // 2
    pad_y = (target_height - resized_height) // 2
    canvas = np.full((target_height, target_width, 3), 114, dtype=np.uint8)
    resized = cv2.resize(image, (resized_width, resized_height), interpolation=cv2.INTER_LINEAR)
    canvas[pad_y : pad_y + resized_height, pad_x : pad_x + resized_width] = resized
    return canvas, ratio, pad_x, pad_y


def evaluate_safety(
    detections: list[Detection],
    *,
    restricted_zone: list[tuple[float, float]] | None = None,
    required_ppe: set[str] | None = None,
) -> list[SafetyFinding]:
    findings: list[SafetyFinding] = []
    people = [detection for detection in detections if detection.label.lower() == "person"]
    ppe = [detection for detection in detections if detection.label.lower() != "person"]
    for item in ppe:
        label = item.label.lower()
        if label.startswith("no-") and label != "no-mask":
            findings.append(
                SafetyFinding(
                    f"missing_{label.removeprefix('no-').replace(' ', '_')}",
                    item.confidence,
                    item.box,
                    "direct missing-PPE model class; human review required",
                )
            )
    for person in people:
        if restricted_zone and violates_restricted_zone(person.box, restricted_zone):
            findings.append(
                SafetyFinding("restricted_zone_entry", person.confidence, person.box, "person")
            )
        if required_ppe:
            associated_labels = {
                item.label.lower()
                for item in ppe
                if _point_inside_box(item.box.centre, person.box)
            }
            detected = {label for label in associated_labels if not label.startswith("no-")}
            directly_missing = {label.removeprefix("no-") for label in associated_labels if label.startswith("no-")}
            for missing in sorted(missing_required_ppe(detected, required_ppe) - directly_missing):
                findings.append(
                    SafetyFinding(
                        f"possible_missing_{missing}",
                        person.confidence,
                        person.box,
                        "inferred from no associated PPE detection; human review required",
                    )
                )
    return findings


def _point_inside_box(point: tuple[float, float], box: Box) -> bool:
    return box.x1 <= point[0] <= box.x2 and box.y1 <= point[1] <= box.y2


def annotate_frame(
    frame: np.ndarray,
    detections: list[Detection],
    findings: list[SafetyFinding],
    *,
    restricted_zone: list[tuple[float, float]] | None = None,
    inference_ms: float | None = None,
) -> np.ndarray:
    annotated = frame.copy()
    if restricted_zone:
        points = np.asarray(restricted_zone, dtype=np.int32)
        cv2.polylines(annotated, [points], True, (0, 165, 255), 2)
    finding_boxes = {finding.box for finding in findings}
    for detection in detections:
        box = detection.box
        color = (0, 0, 255) if box in finding_boxes else (0, 200, 0)
        top_left = (round(box.x1), round(box.y1))
        bottom_right = (round(box.x2), round(box.y2))
        cv2.rectangle(annotated, top_left, bottom_right, color, 2)
        cv2.putText(
            annotated,
            f"{detection.label} {detection.confidence:.2f}",
            (top_left[0], max(18, top_left[1] - 6)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            color,
            2,
        )
    y = 24
    for finding in findings:
        cv2.putText(
            annotated,
            f"ALERT: {finding.event_type}",
            (12, y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (0, 0, 255),
            2,
        )
        y += 26
    if inference_ms is not None:
        cv2.putText(
            annotated,
            f"OpenCV DNN {inference_ms:.1f} ms",
            (12, annotated.shape[0] - 12),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (255, 255, 255),
            1,
        )
    return annotated
