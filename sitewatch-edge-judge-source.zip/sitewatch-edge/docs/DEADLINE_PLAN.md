# Internal deadline plan

Internal deadline: **14 October 2026, 23:59 IST**.

Official Devpost deadline verified 9 October: **27 October 2026, 12:15 IST** at
https://opencv26.devpost.com/. The earlier internal deadline remains unchanged.

| Date | Exit criterion |
|---|---|
| 7 Oct | Scaffold, architecture, offline queue, initial tests |
| 8 Oct | OpenCV 5 environment verified; camera/video ingest works |
| 9 Oct | ONNX detections and local overlay work on licensed footage |
| 10 Oct | PPE and restricted-zone alerts integrated |
| 11 Oct | AWS receiver locally verified; cloud deployment decision ready |
| 12 Oct | Evaluation complete; failure cases documented |
| 13 Oct | Report, diagram, repository instructions, and video complete |
| 14 Oct | Final QA, professor approval checkpoint, Devpost submission |

## Execution record

- 7 Oct: local implementation, OpenCV 5 evidence, evaluation, judge archive, and
  2:32 demonstration video completed.
- 7 Oct: demonstration published unlisted at https://youtu.be/_lm_0y-pqVk.
- 8 Oct: twelve tests and Ruff passed; release audit misses only the live AWS
  round-trip and final Devpost confirmation.
- AWS signup, Individual Aadhaar/DigiLocker KYC, and SMS verification completed on
  11 October. AWS account activation is pending; no resources have been deployed
  and no live cloud claim may be made yet.
- 9 Oct: corrected the obsolete `opencv.devpost.com` address to
  `opencv26.devpost.com`; Google login is paused at the explicit consent screen.
- 9 Oct: judge archive rebuilt; SHA-256
  `b3548df6853ce0c80ec1761458f4155a40aa29f7f2787c6712e653d5e0181278`.
- 10 Oct: reconciled all seven functional-evaluation sources, reviewed the Pexels
  licence/terms, and prepared `docs/IP_INSTITUTIONAL_REVIEW.md`. Entrant
  eligibility, original-work authority, and the exact KLH affiliation wording
  still require the professor's confirmation before submission.
- 10 Oct: twelve tests and Ruff passed; judge archive rebuilt after the review
  updates; its SHA-256 is recorded in
  `dist/sitewatch-edge-judge-source.zip.sha256`.
- 11 Oct: locally verified the complete offline-queue to client to production
  Lambda-handler contract, including removal of the local evidence path before
  storage. Thirteen tests and Ruff pass; live AWS deployment is now activation-gated.
- 11 Oct: AWS displayed the signup confirmation after DigiLocker/Aadhaar and SMS
  verification. Account activation is pending; deployment remains blocked until
  AWS confirms activation.
- 11 Oct: confirmed access to the AWS console in `ap-south-1`. CloudShell refused
  environment creation because new-account verification is still in progress and
  may take up to two days. No resources or charges were created.
- 11 Oct: verified authenticated AWS emails confirming successful customer
  verification and that the Free plan account is active and ready. No further
  verification action is required; deployment/live evidence remains pending.
- 11 Oct: deployed CloudFormation stack `sitewatch-edge-demo` in `ap-south-1`.
  Stack status reached `CREATE_COMPLETE`; the Lambda, HTTP API, DynamoDB table,
  IAM role, and USD 5 monthly budget were created successfully.
- 11 Oct: completed the sanitized live round-trip check. An invalid key returned
  `401`, an authorized synthetic event returned `202`, and the DynamoDB record
  excluded the deliberately supplied local `evidence_path` field. Evidence is in
  `evidence/aws-live-roundtrip.json`.
- 11 Oct: thirteen tests and Ruff passed after deployment evidence was recorded;
  the judge archive was rebuilt and its SHA-256 is recorded beside it in
  `dist/sitewatch-edge-judge-source.zip.sha256`.

## Stop/go gates

1. Do not claim OpenCV 5 compliance until runtime evidence records its version.
2. Do not deploy AWS or incur charges without explicit authorization.
3. Do not upload footage without rights and consent.
4. Do not submit until all required links are judge-accessible and final text has
   been checked for institutional claims.
