# Build status

Updated: 11 October 2026

| Workstream | Status | Evidence |
|---|---|---|
| Project scaffold | Complete | Repository files present |
| OpenCV 5 environment | Verified | OpenCV 5.0.0 in isolated `.venv` |
| Offline event queue | Implemented | Unit tests pass |
| Zone and PPE rule helpers | Implemented | Unit tests pass |
| Delayed HTTP synchronization | Locally verified end to end | Real queue/client serialization reaches production Lambda handler contract; local evidence path is stripped |
| Image ingestion | Verified | Pexels CC0 image processed offline |
| Video ingestion | Verified | Five-frame MP4 processed and re-encoded with overlays |
| Webcam/RTSP ingestion | Implemented, not field-verified | `cv2.VideoCapture` runner |
| YOLOX person detection with OpenCV 5 DNN | Verified | Two people detected on OpenCV sample |
| PPE detection with OpenCV 5 DNN | Verified | Worker, hardhat and safety vest detected on CC0 image |
| Local overlays and restricted-zone alert | Verified | Annotated images and JSONL incident evidence |
| Local operator interface | Verified | HTTP 200, upload workflow unit-tested |
| Licensed evaluation dataset | Complete for functional evaluation | Six Pexels images and one OpenCV sample; sources and licence review documented |
| AWS receiver local verification | Complete | Queue-to-client-to-Lambda contract test passes; `cfn-lint 1.40.4` passes |
| AWS account and deployment | Complete | `sitewatch-edge-demo` reached `CREATE_COMPLETE` in `ap-south-1`; invalid-key `401`, valid synthetic incident `202`, and privacy-minimised DynamoDB persistence verified |
| Small licensed image evaluation | Complete | 7-image functional report; limitations documented |
| Final demo video | Complete, locally verified, and published unlisted | 2:32, 1920×1080, H.264/AAC, English subtitles; https://youtu.be/_lm_0y-pqVk |
| Devpost submission | Current portal verified; login awaits Google consent | https://opencv26.devpost.com/; not submitted |

The authorized AWS deployment completed on 11 October. CloudFormation created the
SiteWatch receiver, HTTP API, encrypted pay-per-request DynamoDB table, generated
IAM role, and USD 5 monthly budget in `ap-south-1`. A live synthetic round trip
verified `401` for an invalid key, `202` for the authorized request, and storage of
only the approved metadata fields. The ingest secret and AWS account identifier
are omitted from evidence. Devpost submission has not occurred.

Latest verification: thirteen tests and Ruff passed on 11 October 2026. The judge
archive was rebuilt and its SHA-256 is recorded beside it in
`dist/sitewatch-edge-judge-source.zip.sha256`.
The release audit previously reported two external gaps; the live AWS gap is now
closed by `evidence/aws-live-roundtrip.json`, leaving
`evidence/submission-confirmation.md`. A simulated three-event
offline queue and real OpenCV 5 inference incidents were generated successfully.
This verifies the end-to-end local path on representative images, not production
accuracy or field-camera performance. The final IP, eligibility, and institutional
claim review is prepared in `docs/IP_INSTITUTIONAL_REVIEW.md`; its participant
confirmations remain open.

The 11 October AWS decision gate is complete: the receiver contract is verified
locally and through the authorized live deployment with sanitized round-trip
evidence.
