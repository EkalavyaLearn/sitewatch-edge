from __future__ import annotations

import json
import os
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from hmac import compare_digest

_table = None


def get_table():
    global _table
    if _table is None:
        import boto3

        _table = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])
    return _table


def handler(event, _context):
    try:
        headers = {key.lower(): value for key, value in (event.get("headers") or {}).items()}
        supplied_key = headers.get("x-api-key", "")
        configured_key = os.environ.get("INGEST_API_KEY", "")
        if not configured_key or not compare_digest(supplied_key, configured_key):
            return response(401, {"accepted": False, "error": "unauthorized"})
        raw_body = event.get("body") or "{}"
        if len(raw_body) > 16_384:
            return response(413, {"accepted": False, "error": "request too large"})
        body = json.loads(raw_body)
        required = {"event_id", "event_type", "observed_at", "confidence"}
        if not required.issubset(body):
            return response(400, {"accepted": False, "error": "missing required fields"})
        confidence = float(body["confidence"])
        if not 0 <= confidence <= 1:
            return response(400, {"accepted": False, "error": "invalid confidence"})
        item = {key: body[key] for key in required}
        item["event_id"] = str(item["event_id"])[:64]
        item["event_type"] = str(item["event_type"])[:80]
        item["observed_at"] = str(item["observed_at"])[:48]
        item["source_id"] = str(body.get("source_id", "unknown"))[:120]
        item["zone_id"] = body.get("zone_id")
        item["expires_at"] = int((datetime.now(UTC) + timedelta(days=30)).timestamp())
        item["confidence"] = Decimal(str(confidence))
        get_table().put_item(Item=item, ConditionExpression="attribute_not_exists(event_id)")
        return response(202, {"accepted": True, "event_id": item["event_id"]})
    except (ValueError, TypeError, json.JSONDecodeError):
        return response(400, {"accepted": False, "error": "invalid request"})


def response(status_code: int, body: dict) -> dict:
    return {
        "statusCode": status_code,
        "headers": {"content-type": "application/json", "cache-control": "no-store"},
        "body": json.dumps(body),
    }
