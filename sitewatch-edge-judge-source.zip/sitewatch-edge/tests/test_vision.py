import cv2
import numpy as np

from sitewatch_edge.rules import Box
from sitewatch_edge.vision import Detection, annotate_frame, evaluate_safety, letterbox


def test_letterbox_preserves_aspect_ratio() -> None:
    image = np.zeros((100, 200, 3), dtype=np.uint8)
    prepared, ratio = letterbox(image, (640, 640))
    assert prepared.shape == (640, 640, 3)
    assert ratio == 3.2


def test_zone_and_missing_ppe_findings_are_advisory() -> None:
    detections = [Detection("person", 0.91, Box(10, 10, 90, 190))]
    findings = evaluate_safety(
        detections,
        restricted_zone=[(0, 0), (100, 0), (100, 200), (0, 200)],
        required_ppe={"helmet"},
    )
    assert {finding.event_type for finding in findings} == {
        "restricted_zone_entry",
        "possible_missing_helmet",
    }
    assert "human review" in findings[1].details


def test_direct_missing_ppe_class_is_reported_without_duplicate_inference() -> None:
    detections = [
        Detection("person", 0.91, Box(10, 10, 90, 190)),
        Detection("no-hardhat", 0.72, Box(35, 12, 65, 45)),
    ]
    findings = evaluate_safety(detections, required_ppe={"hardhat"})
    assert [finding.event_type for finding in findings] == ["missing_hardhat"]
    assert findings[0].confidence == 0.72


def test_annotation_changes_pixels() -> None:
    frame = np.zeros((200, 200, 3), dtype=np.uint8)
    detections = [Detection("person", 0.9, Box(10, 10, 100, 180))]
    findings = evaluate_safety(
        detections,
        restricted_zone=[(0, 0), (150, 0), (150, 199), (0, 199)],
    )
    annotated = annotate_frame(frame, detections, findings, restricted_zone=[(0, 0), (150, 0), (150, 199), (0, 199)])
    assert cv2.countNonZero(cv2.cvtColor(annotated, cv2.COLOR_BGR2GRAY)) > 0
